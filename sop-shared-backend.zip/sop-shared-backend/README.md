# SOP Shared Backend – One-Time Setup, 150 Staff Get Access With No OAuth

This backend lets **all staff view and edit SOPs** without entering an API key or connecting Google Drive. **You** set it up once with a service account; staff just open the app.

---

## 1. One-time setup (you only)

### A. Google Cloud: service account

1. Go to [Google Cloud Console](https://console.cloud.google.com/) → your project (or create one).
2. **APIs & Services** → **Enable** the **Google Drive API**.
3. **APIs & Services** → **Credentials** → **Create credentials** → **Service account**.
4. Name it (e.g. `sop-shared-backend`) → **Create and continue** → **Done**.
5. Open the new service account → **Keys** → **Add key** → **Create new key** → **JSON** → download the JSON file.
6. **Share your SOPs Drive folder with this service account:**
   - Open the JSON file and copy the **`client_email`** (e.g. `sop-shared-backend@your-project.iam.gserviceaccount.com`).
   - In Google Drive, open the folder where you store SOPs (or create one).
   - Right‑click the folder → **Share** → add the `client_email` as **Editor** → Send.

### B. Environment variables

- **SOP_FOLDER_ID** (or **FOLDER_ID**): the ID of that Drive folder (from the folder URL: `https://drive.google.com/drive/folders/FOLDER_ID`).
- **GOOGLE_SERVICE_ACCOUNT_JSON**: the **entire contents** of the JSON key file as a single string (e.g. in Cloud Run: paste the JSON; locally you can `export GOOGLE_SERVICE_ACCOUNT_JSON="$(cat key.json)"`).

### C. Run locally (optional)

```bash
cd sop-shared-backend
npm install
export SOP_FOLDER_ID="your-folder-id"
export GOOGLE_SERVICE_ACCOUNT_JSON='{"type":"service_account",...}'
node index.js
```

Server runs on http://localhost:8080. Test: `curl http://localhost:8080/sops`.

### D. Deploy to Google Cloud Run

1. In Cloud Console: **Cloud Run** → **Create service**.
2. **Source**: upload this folder (or connect a repo).
3. **Build**: use Node 18.
4. **Variables & Secrets** (or **Edit & deploy new revision**):
   - Add **SOP_FOLDER_ID** = your folder ID.
   - Add **GOOGLE_SERVICE_ACCOUNT_JSON** = full JSON key (as secret or multi-line env).
5. Deploy. Note the service URL (e.g. `https://sop-shared-xxxxx.run.app`).

---

## 2. Point the app at the backend (once)

In your SOP app repo, in **index.html**, set:

```javascript
window.SOP_SHARED_API_URL = 'https://your-cloud-run-url.run.app';
```

(Use the URL from step D.)

Redeploy the app (e.g. push to GitHub Pages). After that, **staff do nothing** – they just open the app URL and see SOPs.

---

## 3. Staff experience

- No API key, no OAuth, no “Connect to Google Drive”.
- They open the app → SOPs load from your backend → they can view and edit.
- They never see or touch your Drive or credentials.

---

## API (used by the app)

- `GET /sops` – list all SOPs (returns `{ sops: { id: sop, ... } }`).
- `GET /sops/:id` – get one SOP.
- `POST /sops` – create or update SOP (body: SOP JSON).
- `DELETE /sops/:id` – delete SOP.

CORS is set so your app origin can call the backend.
